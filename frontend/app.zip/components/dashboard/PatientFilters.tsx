"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Glass } from "@/components/ui/Glass";
import {
  parseFromURLSearchParams,
  serializePatientQuery,
  SURGERY_TYPES,
  SEVERITY_FILTER_OPTIONS,
  type PatientListParams,
} from "@/lib/patientQuery";

export function PatientFilters() {
  const router = useRouter();
  const pathname = usePathname();
  const sp = useSearchParams();
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [draft, setDraft] = useState<PatientListParams>(() =>
    parseFromURLSearchParams(new URLSearchParams(sp.toString()))
  );

  useEffect(() => {
    setDraft(parseFromURLSearchParams(new URLSearchParams(sp.toString())));
  }, [sp]);

  const apply = () => {
    const next = { ...draft };
    const qs = serializePatientQuery(next);
    router.push(qs ? `${pathname}?${qs}` : pathname);
  };

  const clear = () => {
    setDraft({});
    router.push(pathname);
  };

  const toggleSeverity = (value: string) => {
    setDraft((d) => {
      const cur = d.severity ?? [];
      const has = cur.includes(value);
      const next = has ? cur.filter((x) => x !== value) : [...cur, value];
      const out: PatientListParams = {
        ...d,
        severity: next.length ? next : undefined,
      };
      return out;
    });
  };

  const sevClass = (value: string, selected: boolean): string => {
    const base =
      "rounded-full border px-3 py-1.5 text-xs font-semibold transition-colors";
    if (!selected) {
      return `${base} border-blue-400/25 bg-blue-950/35 text-blue-100/90 hover:border-blue-400/40 hover:bg-blue-900/45`;
    }
    switch (value) {
      case "stable":
        return `${base} border-emerald-600 bg-emerald-600 text-white`;
      case "at_risk":
        return `${base} border-amber-400 bg-amber-400 text-slate-900`;
      case "severe":
        return `${base} border-orange-500 bg-orange-500 text-white`;
      case "911":
        return `${base} border-rose-600 bg-rose-600 text-white`;
      default:
        return `${base} border-blue-300 bg-blue-50 text-blue-950`;
    }
  };

  return (
    <Glass className="p-4">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
        <div className="flex-1">
          <div className="mb-1 text-[11px] text-slate-400">Search by name</div>
          <div className="flex w-full items-center gap-2 rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 ring-1 ring-white/[0.04]">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              className="h-4 w-4 shrink-0 text-slate-500"
              aria-hidden
            >
              <path
                d="M21 21l-4.3-4.3M11 18a7 7 0 110-14 7 7 0 010 14z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
            </svg>
            <input
              type="text"
              className="min-w-0 flex-1 bg-transparent text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none"
              value={draft.q ?? ""}
              onChange={(e) =>
                setDraft((d) => ({ ...d, q: e.target.value || undefined }))
              }
              placeholder="Search by name…"
            />
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={apply}
            className="rounded-xl bg-blue-500 px-3 py-2 text-sm font-medium text-white shadow-sm ring-1 ring-blue-300/40 hover:bg-blue-400"
          >
            Apply
          </button>
          <button
            type="button"
            onClick={clear}
            className="rounded-xl border border-blue-400/35 bg-blue-950/40 px-3 py-2 text-sm font-medium text-blue-100 ring-1 ring-white/[0.04] hover:border-blue-300/50 hover:bg-blue-900/50"
          >
            Clear
          </button>
          <button
            type="button"
            onClick={() => setShowAdvanced((v) => !v)}
            className="rounded-xl border border-blue-400/25 bg-blue-600/20 px-3 py-2 text-sm font-medium text-blue-50 ring-1 ring-white/[0.04] hover:border-blue-300/45 hover:bg-blue-500/30"
          >
            {showAdvanced ? "Advanced ▾" : "Advanced ▸"}
          </button>
        </div>
      </div>

      {showAdvanced ? (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <label className="flex flex-col gap-1 text-[11px] text-slate-400">
              Surgery
              <select
                className="rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 text-sm text-slate-200 outline-none ring-1 ring-white/[0.04] focus:border-blue-400/40 focus:ring-2 focus:ring-blue-500/40"
                value={draft.surgery_type ?? ""}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    surgery_type: e.target.value || undefined,
                  }))
                }
              >
                <option value="">Any</option>
                {SURGERY_TYPES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-slate-400">
              Discharge from
              <input
                type="datetime-local"
                className="rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 text-sm text-slate-200 outline-none ring-1 ring-white/[0.04] focus:border-blue-400/40 focus:ring-2 focus:ring-blue-500/40"
                value={toLocalInput(draft.discharge_from)}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    discharge_from: fromLocalInput(e.target.value) || undefined,
                  }))
                }
              />
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-slate-400">
              Discharge to
              <input
                type="datetime-local"
                className="rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 text-sm text-slate-200 outline-none ring-1 ring-white/[0.04] focus:border-blue-400/40 focus:ring-2 focus:ring-blue-500/40"
                value={toLocalInput(draft.discharge_to)}
                onChange={(e) =>
                  setDraft((d) => ({
                    ...d,
                    discharge_to: fromLocalInput(e.target.value) || undefined,
                  }))
                }
              />
            </label>
          </div>

          <div>
            <div className="mb-2 text-[11px] font-medium text-slate-400">Severity</div>
            <div className="flex flex-wrap gap-2">
              {SEVERITY_FILTER_OPTIONS.map(({ value, label }) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => toggleSeverity(value)}
                  className={sevClass(value, !!draft.severity?.includes(value))}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              Filters are based on the latest scored call.
            </div>
          </div>
        </div>
      ) : null}
    </Glass>
  );
}

/** ISO string to datetime-local value (local). */
function toLocalInput(iso: string | undefined): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function fromLocalInput(v: string): string | undefined {
  if (!v) return undefined;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toISOString();
}
