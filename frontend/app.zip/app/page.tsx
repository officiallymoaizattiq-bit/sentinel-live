import { Suspense } from "react";
import { api } from "@/lib/api";
import { parsePatientQuery, patientQueryKey } from "@/lib/patientQuery";
import { AlertFeed } from "@/components/AlertFeed";
import { KpiStrip } from "@/components/dashboard/KpiStrip";
import { PatientFilters } from "@/components/dashboard/PatientFilters";
import { PatientGrid } from "@/components/dashboard/PatientGrid";
import { ConvaiWidget } from "@/components/ConvaiWidget";
import { FinalizeButton } from "@/components/FinalizeButton";

export const revalidate = 0;

type CallSummary = {
  series: number[];
  lastDeterioration: number | null;
  lastAction: string | null;
  lastCalledAt: string | null;
};

const EMPTY: CallSummary = {
  series: [],
  lastDeterioration: null,
  lastAction: null,
  lastCalledAt: null,
};

export default async function Dashboard({
  searchParams,
}: {
  searchParams: Record<string, string | string[] | undefined>;
}) {
  const patientParams = parsePatientQuery(searchParams);
  const filterKey = patientQueryKey(patientParams);

  const [patients, alerts] = await Promise.all([
    api.patients(patientParams).catch(() => []),
    api.alerts().catch(() => []),
  ]);

  const summaryEntries = await Promise.all(
    patients.map(async (p): Promise<readonly [string, CallSummary]> => {
      try {
        const calls = await api.calls(p.id);
        const series = calls
          .filter((c) => c.score)
          .map((c) => c.score!.deterioration);
        const last = calls[calls.length - 1];
        return [
          p.id,
          {
            series,
            lastDeterioration: last?.score?.deterioration ?? null,
            lastAction: last?.score?.recommended_action ?? null,
            lastCalledAt: last?.called_at ?? null,
          },
        ] as const;
      } catch {
        return [p.id, EMPTY] as const;
      }
    })
  );
  const summaries: Record<string, CallSummary> =
    Object.fromEntries(summaryEntries);

  const lastDets = Object.values(summaries)
    .map((s) => s.lastDeterioration)
    .filter((v): v is number => typeof v === "number");
  const avgDeterioration =
    lastDets.length > 0
      ? lastDets.reduce((a, b) => a + b, 0) / lastDets.length
      : null;

  const agentId = process.env.NEXT_PUBLIC_ELEVENLABS_AGENT_ID ?? "";

  return (
    <div className="space-y-6">
      <KpiStrip
        initialPatients={patients}
        initialAlerts={alerts}
        initialAvgDeterioration={avgDeterioration}
        patientParams={patientParams}
        queryKey={filterKey}
      />

      <div id="patients" className="scroll-mt-24 flex items-center justify-between">
        <div>
          <h2 className="text-sm font-semibold tracking-tight text-white text-on-glass">
            Monitored patients
          </h2>
          <p className="text-[11px] text-slate-400">
            Status reflects the most recent scored call
          </p>
        </div>
        <span className="text-[11px] text-slate-500">
          {patients.length} total
        </span>
      </div>

      <Suspense
        fallback={
          <div className="h-32 animate-pulse rounded-xl bg-white/[0.04] ring-1 ring-white/10" />
        }
      >
        <PatientFilters />
      </Suspense>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <section className="min-w-0 lg:col-span-2 space-y-6">
          <PatientGrid
            initialPatients={patients}
            initialSummaries={summaries}
            patientParams={patientParams}
            queryKey={filterKey}
          />
          <ConvaiWidget agentId={agentId} />
          <FinalizeButton />
        </section>

        <aside id="alerts" className="scroll-mt-24 min-w-0">
          <div className="lg:sticky lg:top-4">
            <AlertFeed initial={alerts} />
          </div>
        </aside>
      </div>
    </div>
  );
}
